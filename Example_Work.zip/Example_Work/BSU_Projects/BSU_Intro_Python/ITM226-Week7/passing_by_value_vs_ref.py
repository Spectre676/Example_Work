def modify_list(my_list):
   """
   This function adds the int 4 to the list
   Created by ABC
   Dept:
   Tel:
   Email:
   Super:
   """
   
   my_list.append(4)

original_list = [1, 2, 3]
modify_list(original_list)

print(original_list)
print(modify_list.__doc__)