print(f'{"Player Name":<16}{"Goals":<8}')
print('_' * 24)
print(f'{"Anna Manthis":>16}{"22":>8}')
print(f'{"Rob Smith":^16}{"1":^8}')